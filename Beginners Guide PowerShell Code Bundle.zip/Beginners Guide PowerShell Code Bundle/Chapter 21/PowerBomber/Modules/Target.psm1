﻿
Class Target
{
    [int]$distance
    [GameObject]$object
        
    Target()
    {
        $this.distance = 999
    }
}